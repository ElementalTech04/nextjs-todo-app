

export enum AuthFlows {
    DEV,
    PROD,
    DEMO
}
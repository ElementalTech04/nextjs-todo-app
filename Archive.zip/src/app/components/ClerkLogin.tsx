export const ClerkLogin = () => {
    return (
        <div className="flex flex-col items-center justify-center h-screen">
            <div className="w-full max-w-md">
                <div className="flex flex-col items-center justify-center">
                    <div className="w-full">
                    </div>
                </div>
            </div>
        </div>
    );
}
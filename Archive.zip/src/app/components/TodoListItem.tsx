'use client';

import {TodoItem} from "@/interface/types";

export default function TodoListItem({ todo: todo }: { todo: TodoItem }) {
    // Determine the circle color based on the priority level
    const getPriorityColor = () => {
        switch (todo.priority) {
            case 1:
                return 'bg-red-500';  // High priority (Red)
            case 2:
                return 'bg-yellow-400';  // Medium priority (Yellow)
            case 3:
                return 'bg-green-500';  // Low priority (Green)
            default:
                return 'border-2 border-gray-400';  // No priority (Outline)
        }
    };

    return (
        <div className="flex items-center space-x-4 bg-white p-4 rounded-lg shadow-md mb-4">
            {/* Priority Icon (circle) */}
            <div className={`h-8 w-8 rounded-full ${getPriorityColor()}`} />

            {/* Task Information */}
            <div className="flex-grow">
                <h3 className="text-3xl font-bold">{todo.title}</h3>
                <p className="text-gray-600">{todo.description}</p>
            </div>

            {/* Due Date */}
            <div>
                <span className="text-gray-500 text-sm">Due: {todo.dueDate?.toLocaleDateString()}</span>
            </div>
        </div>
    );
}

import TodoListItem from "@/app/components/TodoListItem";


export const TodoList = ({ todos: todos, listType: listType }: { todos: any, listType: string }) => {
    console.log(todos)
    return (
        <div className="text-white rounded-lg bg-gray-800 p-4 shadow-md">
            {todos.length > 0 ? todos.map((todo, index) => (
                <div key={index}>
                    <TodoListItem todo={todo} />
                </div>
            )):
                <div>No todos found</div>
            }
        </div>
    )
}
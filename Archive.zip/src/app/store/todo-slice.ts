import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import {TodoItem} from "@/interface/types";

interface TodoState {
    todos: TodoItem[];
}

const initialState: TodoState = {
    todos: [],
};

// Utility method to update object with differences between two objects
const updateObjectWithDifferences = (objA, objB) => {
    for (const key in objB) {
        if (objB.hasOwnProperty(key)) {
            if (typeof objB[key] === 'object' && !Array.isArray(objB[key]) && objB[key] !== null) {
                // If the property is an object, perform deep merge
                objA[key] = updateObjectWithDifferences(objA[key] || {}, objB[key]);
            } else if (objA[key] !== objB[key]) {
                // Update objA if values are different or if the key doesn't exist in objA
                objA[key] = objB[key];
            }
        }
    }
    return objA;
}

const todoSlice = createSlice({
    name: 'todos',
    initialState,
    reducers: {
        addTodo: (state, action: PayloadAction<{ id: string; task: string }>) => {
            state.todos.push({ ...action.payload, completed: false });
        },
        toggleTodo: (state, action: PayloadAction<string>) => {
            const todo = state.todos.find((todo) => todo.id === action.payload);
            if (todo) {
                todo.completed = !todo.completed;
            }
        },
        modifyTodo: (state, action: PayloadAction<TodoItem>) => {
            const todo: TodoItem = state.todos.find((todo: TodoItem) => todo.id === action.payload.id);
            if (todo) {
                 updateObjectWithDifferences(todo, action.payload);
            }
        },
        removeTodo: (state, action: PayloadAction<string>) => {
            state.todos = state.todos.filter((todo) => todo.id !== action.payload);
        },
    },
});

export const { addTodo, toggleTodo, modifyTodo, removeTodo } = todoSlice.actions;
export default todoSlice.reducer;

'use client';
import {redirect, useRouter, useSearchParams} from 'next/navigation';  // Import redirect for server-side redirection
import React, {useEffect} from 'react';
import {TodoList} from '@/app/components/TodoList';
import {AuthFlows, TodoItem} from '@/interface/types';
import {cookies} from "next/headers";
import {getCookie} from "cookies-next";
import jwt from "jsonwebtoken";

export default function TodoPage() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const authFlow = searchParams.get('flow') || AuthFlows.DEMO
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);
    const [todoData, setTodoData] = React.useState<any[]>([]);
    const loginUrl = `/auth/login?authFlow=${authFlow}&originPath=/todo`;

    // Get JWT for backend authentication
    const authToken = getCookie(process.env.NEXT_PUBLIC_AUTH_TOKEN_KEY) || "";

    // Fail fast if no auth token is found
    if (!authToken) {
        router.push(loginUrl);  // Redirect to the login page
    }

    // Fetch Todo data for the authenticated user
    const getTodoData = async () => {
        const todoUrl = `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/todo-api?flow=${authFlow}`;
        const response = await fetch(todoUrl, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            }
        })
        return await response.json();

    }

    useEffect(() => {
        console.log('useEffect');
        if (!isAuthenticated) {
            // when the UI refreshes, check authentication status and fetch todo data
            fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/auth-api?token=${authToken}`)
                .then(async (res) => {
                    const response = await res.json();
                    console.log(response);

                    // Redirect to login page if not authenticated
                    if (!response.success) {
                        router.push(loginUrl);
                    }
                    setIsAuthenticated(true);

                    const responseData = await getTodoData();

                    setTodoData(responseData);
                })
                .catch(err => {
                    console.error('Authentication failed', err);
                    return null;
                });
        }
    }, []);


    // Render the Header, Todo list, and Completed Todo list
    return (
        <div
            className="h-screen bg-gray-700 rounded-lg w-full text-center p-24 grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 lg:gap-4">
            <div></div>
            <div>
                <TodoList todos={todoData || []} listType={"u"}/>
            </div>
            <div>
                <TodoList todos={todoData || []} listType={"c"}/>
            </div>
        </div>
    );
}

import React from "react";

export const TodoPage = () => {
    return (
        <div>
            <h1>Todo Page</h1>
        </div>
    );
}